# bayesGARCH
Bayesian Estimation of the GARCH(1,1) Model with Student-t Innovations.

[![DOI](https://zenodo.org/badge/59887397.svg)](https://zenodo.org/badge/latestdoi/59887397)

